
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Catholic_News_Online Admin Panel</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/fontastic.css')); ?>">
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/style.default.css')); ?>" id="theme-stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.png')); ?>">
    

  </head>
  <body>
        <div class="page login-page">
          <div class="container d-flex align-items-center">
            <div class="form-holder has-shadow">
              <div class="row">
                
                <div class="col-lg-6">
                  <div class="info d-flex align-items-center">
                    <div class="content">
                      <div class="logo">
                        <h1>CatholicNewsOnline</h1>
                      </div>
                      <p>Login page</p>
                    </div>
                  </div>
                </div>
                
                <div class="col-lg-6 bg-white">
                  <div class="form d-flex align-items-center">
                    <div class="content">

                    <form method="POST" class="form-validate" action="<?php echo e(route('login')); ?>">
                        <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                        <div class="form-group">

                            <input id="email" type="text" value="<?php echo e(old('email')); ?>" name="email" required data-msg="Please enter your email" class="input-material">
                            <label for="email" class="label-material">Email</label>

                            <?php if($errors->has('email')): ?>
                              <font size="2" color="red"><?php echo e($errors->first('email')); ?></font> 
                            <?php endif; ?>
                          
                        </div>

                        <div class="form-group">

                          <input id="password" type="password" name="password" required data-msg="Please enter your password" class="input-material">
                          <label for="password" class="label-material">Password</label>

                          <?php if($errors->has('password')): ?>
                            <font size="2" color="red"><?php echo e($errors->first('password')); ?></font> 
                          <?php endif; ?>
                        
                        </div>

                        
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Login')); ?>

                        </button>
                      
                    </form>
                  <p style="margin-top:10px;"> Not a registered user? <a href="<?php echo e(route('register')); ?>">Register here!</a></p>
                  <p> Back to <a href="<?php echo e(url('/')); ?>">Home</a></p>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
      <div class="copyrights text-center">
        
          <p>Developed by Nishendra Perera</p>
      </div>
    </div>

    
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/popper.js/umd/popper.min.js')); ?>"> </script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery.cookie/jquery.cookie.js')); ?>"> </script>
    <script src="<?php echo e(asset('vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/front.js')); ?>"></script>
  </body>
</html>

<?php /**PATH C:\xampp\htdocs\nishe\resources\views/auth/login.blade.php ENDPATH**/ ?>