<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Catholic News Online - User Panel</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/fontastic.css')); ?>">
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/style.default.css')); ?>" id="theme-stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.png')); ?>">

      <link rel="stylesheet" href="<?php echo e(asset('dataTable/dataTables.bootstrapv4.css')); ?>">

      <link rel="stylesheet" href="https://cdn.datatables.net/select/1.2.7/css/select.dataTables.min.css">

      <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.bootstrap4.min.css">

    <?php if(Route::currentRouteName()=="article.create"||Route::currentRouteName()=="article.edit"): ?>
      <link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
      
    <?php endif; ?>

    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('datetime/bootstrap-datetimepicker.min.css')); ?>">

    <?php $role = \App\Role::select('name')->where('id', Auth::user()->role_id)->first()->name; ?>

  </head>
  <body>

  <div id="LoadingImage" style="position:fixed; width: 100px; height:100px; left: 50%; top:50%; z-index: 20;">
  <img src="<?php echo e(asset('img/loading.gif')); ?>" />
  </div>

    <div class="page" id="page" style="display:none;">
      
      <header class="header">
        <nav class="navbar">
          
          <div class="search-box">
            <button class="dismiss"><i class="icon-close"></i></button>
            <form id="searchForm" role="search">
              <input type="search" id="searchKey" placeholder="Please enter a serial number...." class="form-control">
            </form>
          </div>
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              
              <div class="navbar-header">
                <a href="<?php echo e(route('home')); ?>" class="navbar-brand">
                  <div class="brand-text brand-big"><span>CatholicNews</span><strong>Online</strong></div>
                  <div class="brand-text brand-small"><strong>CP</strong></div></a>
                <a id="toggle-btn" href="#" class="menu-btn active"><span></span><span></span><span></span></a>
              </div>
              
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">

                <li class="nav-item dropdown"> <a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i></a></li>
      
                
              <li class="nav-item"><a href="javascript:void(0)" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="nav-link logout">Logout, <?php echo e(Auth::user()->name); ?><i class="fa fa-sign-out"></i></a></li>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                  <?php echo csrf_field(); ?>
                </form>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <div class="page-content d-flex align-items-stretch"> 
        
        <nav class="side-navbar" style="height:auto;">
          
          <div class="sidebar-header d-flex align-items-center">
            <div class="title">
              <h1 class="h4"><?php echo e(Auth::user()->name); ?></h1>
              <p><?php echo e(ucfirst($role)); ?></p>
            </div>
          </div>

          <ul class="list-unstyled" style="overflow-y: auto; max-height:100%;">

            <?php if($role!="User"): ?>
              <li>
                <a href="#articleDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-form"></i>Articles </a>
                <ul id="articleDropdown" class="collapse list-unstyled">
                  <li><a href="<?php echo e(route('article.home')); ?>">All</a></li>
                  <li><a href="<?php echo e(route('article.create')); ?>">New</a></li>
                </ul>
              </li>
            <?php endif; ?>


              <li><a href="#adDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-pencil-case"></i>Advertisements </a>
                <ul id="adDropdown" class="collapse list-unstyled ">
                    <li><a href="<?php echo e(route('advertisement.home')); ?>">All</a></li>
                    
                      <li><a href="<?php echo e(route('advertisement.create')); ?>">New</a></li>
                    
                    <?php if($role!="User"): ?>
                      <li><a href="<?php echo e(route('advertisement.price')); ?>">Price</a></li>
                    <?php endif; ?>
                </ul>
              </li>

              <li><a href="#orderDropdown" aria-expanded="false" data-toggle="collapse" id="invoiceNotification"> <i class="icon-bill" ></i>Orders </a>
                <ul id="orderDropdown" class="collapse list-unstyled ">
                    <li><a href="<?php echo e(route('order.home')); ?>">All</a></li>
                    
                    <li><a href="<?php echo e(route('order.create')); ?>">New</a></li>
                    
                </ul>
              </li>

              <?php if($role!="User"): ?>
                <li><a href="#previousDropdown" aria-expanded="false" data-toggle="collapse" id="paymentNotification"> <i class="icon-check"></i>Previous Newspapers </a>
                  <ul id="previousDropdown" class="collapse list-unstyled ">
                      <li><a href="<?php echo e(route('previous.home')); ?>">All</a></li>
                      <li><a href="<?php echo e(route('previous.create')); ?>">New</a></li>
                  </ul>
                </li>
              <?php endif; ?>

              <li><a href="#videoDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Videos </a>
                <ul id="videoDropdown" class="collapse list-unstyled ">
                    <li><a href="<?php echo e(route('video.home')); ?>">All</a></li>
                    
                      <li><a href="<?php echo e(route('video.create')); ?>">New</a></li>
                    
                </ul>
              </li>

              <?php if($role=="Admin"): ?>
                <li><a href="<?php echo e(route('user.management.home')); ?>"> <i class="icon-user"></i>Users </a></li>
              <?php endif; ?>

              <?php if($role=="Admin"): ?>
                <li><a href="#reportDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Reports </a>
                  <ul id="reportDropdown" class="collapse list-unstyled ">
                      <li><a href="<?php echo e(route('report.advertisement')); ?>">Advertisement</a></li>
                  </ul>
                </li>
              <?php endif; ?>

              <li><a href="#settingDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-list"></i>Settings </a>
                <ul id="settingDropdown" class="collapse list-unstyled ">
                    <li><a href="<?php echo e(route('setting.home')); ?>">Password Change</a></li>
                    <?php if($role!="User"): ?>
                      <li><a href="<?php echo e(route('setting.slider')); ?>">Slider</a></li>
                    <?php endif; ?>
                </ul>
              </li>
            
          </ul>
        </nav>
        <div class="content-inner">
          
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom"><?php echo $__env->yieldContent('title'); ?></h2>
            </div>
          </header>
          
          <?php echo $__env->yieldContent('content'); ?>
          
          
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                <p>Catholic News Online &copy; <?php echo e(date('Y')); ?></p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Developed by Nishendra Perera</p>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>

    
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/popper.js/umd/popper.min.js')); ?>"> </script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery.cookie/jquery.cookie.js')); ?>"> </script>

    <script src="<?php echo e(asset('vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>

      <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>

      

      <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.bootstrap4.min.js"></script>

        
        <script type="text/javascript" language="javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js">
        </script>
        
        
        <script type="text/javascript" language="javascript" src="//cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js">
        </script>
        
      
    

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>


    <?php if(Route::currentRouteName()=="article.create"||Route::currentRouteName()=="article.edit"): ?>
      
      <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <?php endif; ?>

    <script type="text/javascript" src="<?php echo e(asset('datetime/bootstrap-datetimepicker.js')); ?>"></script>

    
    <script src="<?php echo e(asset('js/front.js')); ?>"></script>

    <script>    
      window.onload = function() {
        document.getElementById("LoadingImage").style.display = "none";
        document.getElementById("page").style.display = "block";
      };
      
    </script>

    

    
    

  </body>
</html><?php /**PATH C:\xampp\htdocs\nishe\resources\views/layouts/main.blade.php ENDPATH**/ ?>