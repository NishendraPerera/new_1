<?php $__env->startSection('content'); ?>

<!--================Home Banner Area =================-->

    <!--================Blog Area =================-->

    <style>
        .links a{
            color: black !important;
        }
    </style>
    
    <!--================Blog Area =================-->
    <section class="blog_area padding_top">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mb-5 mb-lg-0">
                    <div class="blog_left_sidebar">

                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="blog_item">
                                <div class="blog_item_img">
                                    
                                    
                                    <video
                                        id="my-video"
                                        class="video-js vjs-big-play-centered vjs-16-9"
                                        controls
                                        preload="none"
                                        poster="<?php echo e($video->thumbnail_link); ?>"
                                        style=" width: 100%; "
                                        data-setup="{}">
                                        <source src="<?php echo e($video->link); ?>" type="video/mp4" />
                                    </video>
                                </div>
    
                                <div class="blog_details">
                                    
                                        <h2><?php echo e($video->title); ?></h2>
                                    
                                    <p><?php echo e($video->description); ?></p>
                                    <ul class="blog-info-link">
                                        <li><a href="#"><i class="far fa-user"></i> <?php echo e($video->user); ?></a></li>
                                        <li><a href="#"> <?php echo e($video->date); ?></a></li>
                                    </ul>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <nav>
                            <ul class="pagination justify-content-center pagination-lg">
                                <?php echo e($videos->links()); ?>

                            </ul>
                        </nav>

                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="blog_right_sidebar">  

                        <aside class="single_sidebar_widget popular_post_widget">
                            <h3 class="widget_title">Recent Articles</h3>

                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="media post_item">
                                    
                                    <div class="media-body">
                                        <a href="<?php echo e(route('single', ['id' => $article->id ])); ?>">
                                            <h3><?php echo e($article->title); ?></h3>
                                        </a>
                                        <p><?php echo e($article->date); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </aside>                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================Blog Area =================-->
                

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nishe\resources\views/frontend/videos.blade.php ENDPATH**/ ?>