<?php $__env->startSection('title'); ?>
Article/ Edit/ <a href="<?php echo e(route('article.edit', ['id' => $article->id ])); ?>"><?php echo e($article->id); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section>
    <div class="container-fluid">
        <div id="message">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <ul>
                    <?php echo e(session('success')); ?>

                    </ul>
                </div>
            <?php endif; ?>

            <?php if(Session::has('warning')): ?>       
                <div class="alert alert-warning">
                    <ul>
                    <?php echo e(session('warning')); ?>

                    </ul>
                </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="card border-dark">
                    <div class="card-header">Edit article</div>
                    <div class="card-body text-dark">
                        <form class="form-horizontal" name="article_add">

                            <div class="form-group" style="margin-top: 20px;">
                                <label for="oldPass" class="col-sm-6 control-label">Title</label>
                                <div class="col-sm-6">
                                <input type="text" class="form-control" id="title" name="title" placeholder="Title" value="<?php echo e($article->title); ?>">
                                </div>
                            </div>       
                            <div class="form-group" style="margin-top: 20px;">
                                <label for="article_option" class="col-sm-6 control-label">Article Option</label>
                                <div class="col-sm-6">
                                    <select class="form-control" id="article_option" name="article_option">
                                        <?php $__currentLoopData = $article_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($article_option->id); ?>" <?php if($article_option->id==$article->article_option_id): ?> selected <?php endif; ?>><?php echo e($article_option->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div> 
                            </div>     

                            <div class="form-group" style="margin-top: 20px;">
                                <label for="uploaded" class="col-sm-6 control-label">Uploaded image</label>
                                <div class="col-sm-6">
                                    <p> <a href="<?php echo e($article->link); ?>" target="_blank"><?php echo e($article->file_name); ?></a></p>
                                </div> 
                            </div>

                            <div class="form-group" style="margin-top: 20px;">
                                <label for="file" class="col-sm-6 control-label">Upload new file</label>
                                <div class="col-sm-6">
                                    <input type="file" class="form-control-file" id="file" name="file">
                                </div>
                            </div>
                            
                            

                            <textarea id="article" name="article"><?php echo e($article->content); ?></textarea>

                            <div class="form-group" style="margin-top: 20px;">
                                <div class="col-sm-offset-3 col-sm-10">
                                <button type="submit" class="btn btn-primary">Edit Article</button>
                                </div>
                            </div>
        
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<script>
    $(document).ready( function() {


        tinymce.init({
            selector: 'textarea#article',
            plugins: 'link code image imagetools',
            height: 600
        });

        // var ed = tinymce.get('article');
        // ed.setContent("Niroshan");
    });

    // var decodeHTML = function (html) {
    //     var txt = document.createElement('textarea');
    //     txt.innerHTML = html;
    //     return txt.value;
    // }

    $(function() {

        $("form[name='article_add']").validate({
            rules: {
                title: {
                    required: true
                },
                article_option: {
                    required: true
                },
            },
            messages: {
                title: {
                 required: "Please enter a title"
                },
                article_option: {
                    required: "Please select an option"
                },                
            },
            errorElement: "div",
            errorClass: 'is-invalid',
            validClass: 'is-valid',
            ignore: ':hidden:not(.summernote, .checkbox-template, .form-control-custom),.note-editable.card-block',
            errorPlacement: function (error, element) {
                error.addClass("invalid-feedback");
                console.log(element);
                if (element.prop("type") === "checkbox") {
                    error.insertAfter(element.siblings("label"));
                } 
                else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function(form) {
                
                //var content = $("#article").summernote("code");
                var content = $("#article").val();
                var token = "<?php echo e(Session::token()); ?>";

                $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });

                var form_data = new FormData();
                form_data.append('title', $("#title").val());
                form_data.append('article_option', $("#article_option").val());
                form_data.append('content', content);
                form_data.append('file', $('#file').prop('files')[0]);
                form_data.append('_token', token);
                        
                $.ajax({
                    url: "<?php echo e(route('article.update', ['id' => $article->id ])); ?>",
                    type: "post",
                    data: form_data,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (data) {

                        if(data=="Success"){
                            location.reload(true);
                        }
                        else{
                            $.alert({
                                type: 'red',
                                title: 'Error!',
                                content: "An error occured!",
                            });
                        }
                    },
                    error: function (data) {
                        console.log(data.responseText);
                        window.scrollTo(0, 0);
                        $('#message').html('<div class="alert alert-danger">Request Failed!</div>');
                    }
                });
                
            }
        });


    }); 
</script>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nishe\resources\views/article/edit.blade.php ENDPATH**/ ?>