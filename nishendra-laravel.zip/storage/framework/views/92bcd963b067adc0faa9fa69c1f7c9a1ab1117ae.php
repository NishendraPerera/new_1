 

<?php
    $role = \App\Role::select('name')->where('id', Auth::user()->role_id)->first()->name;
?>

<?php $__env->startSection('title'); ?>
Report/ <a href="<?php echo e(route('report.advertisement')); ?>">Advertisement</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section>
    <div class="container-fluid">

        <div id="message">
            <?php if(Session::has('success')): ?>       
                <div class="alert alert-success">
                    <ul>
                    <?php echo e(session('success')); ?>

                    </ul>
                </div>
            <?php endif; ?>

            <?php if(Session::has('warning')): ?>       
                <div class="alert alert-warning">
                    <ul>
                    <?php echo e(session('warning')); ?>

                    </ul>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="row">
            <div class="col-sm-12">
                <div class="card border-dark">
                    <div class="card-header">Advertisement Report</div>
                    <div class="card-body text-dark">
                        <div class="row">
                            <div class="col-sm-4">
                                <input type="text" class="form-control" value="<?php echo e(date('Y-m-d', strtotime('-1 months'))); ?>" placeholder="Start Date" id="start" readonly="">
                            </div>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" placeholder="End Date" id="end" readonly="">
                            </div>
                        </div>

                        <div class="row" style="margin-top: 10px;">
                            <div class="col-sm-4">
                                <select class="form-control" placeholder="Executive" id="customerName" name="customerName">
                                    <option value="0">All Users</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                            <div class="col-sm-4">
                                <select class="form-control" id="salesMonth" name="salesMonth">
                                    <option value="0">All Months</option>
                                    <option value="LOctober">Last October</option>
                                    <option value="LNovember">Last November</option>
                                    <option value="LDecember">Last December</option>
                                    <option value="January">January</option>
                                    <option value="February">February</option>
                                    <option value="March">March</option>
                                    <option value="April">April</option>
                                    <option value="May">May</option>
                                    <option value="June">June</option>
                                    <option value="July">July</option>
                                    <option value="August">August</option>
                                    <option value="September">September</option>
                                    <option value="October">October</option>
                                    <option value="November">November</option>
                                    <option value="December">December</option>
                            </select>
                            </div>
                            
                        </div>

                        <div class="row" style="margin-top: 10px;">
                            <div class="col-sm-3">
                                <select class="form-control" id="category" name="category">
                                    <option value="0">All Categories</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-sm-3">
                                <select class="form-control" id="size" name="size">
                                    <option value="0">All Sizes</option>
                                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($size->id); ?>"><?php echo e($size->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-sm-3">
                                <select class="form-control" id="colour" name="colour">
                                    <option value="0">All Colour Options</option>
                                    <?php $__currentLoopData = $colours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($colour->id); ?>"><?php echo e($colour->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            <div class="col-sm-3">
                                <button type="submit" id="update" class="btn btn-success">Update</button>
                            </div>
                        </div>

                        <form class="form-inline" style="margin-top: 30px;">                        
                            <div class="form-group">
                                <div class="col-sm-12">
                                <p class="form-control-static" id="from"></p>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                <p class="form-control-static" id="to"></p>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                <p class="form-control-static" id="tableCustomer" ></p>
                                </div>
                            </div>      
                        </form>

                        <form class="form-inline" style="margin-top: 10px;">                        
                            <div class="form-group">
                                <div class="col-sm-12">
                                <p class="form-control-static" id="category_text"></p>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                <p class="form-control-static" id="size_text"></p>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                <p class="form-control-static" id="colour_text" ></p>
                                </div>
                            </div>      
                        </form>
    
                        <form class="form-inline" style="margin-top: 10px;">                                
                            <div class="form-group">
                                <div class="col-sm-12">
                                <p class="form-control-static" id="amount"></p>
                                </div>
                            </div>        
                        </form>

                        <div class="table-responsive">
                            <table id="advertisement" class="table table-hover table-bordered" width="100%" cellspacing="0">
                                <thead>
                                    <tr><th>ID</th><th>Category</th><th>Size</th><th>Colour</th><th>Submitted On</th><th>User Name</th><th>Price</th></tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
                      
        </div>
    </div>

</section>

<script type="text/javascript">
          
    $( document ).ready( function () {

        var table = $('#advertisement').DataTable({
                "bLengthChange": false, "pagingType": "simple", "ordering": false, dom: 'Bfrtip', buttons:[{ extend: 'excel', text: 'Save as Excel', title: 'Advertisement Report' } ],
                language: { search: "_INPUT_", searchPlaceholder: "Search..." },
                "ajax": {url : "<?php echo e(route('report.ad_list')); ?>"
                , data : function(d) { d.starting = document.getElementById("start").value; d.ending = document.getElementById("end").value; d.salesMonth = document.getElementById("salesMonth").value; d.customer = document.getElementById("customerName").value; 
                d.category = document.getElementById("category").value; d.colour = document.getElementById("colour").value; d.size = document.getElementById("size").value;}
                , dataSrc : function(json){ $('#from').html("<b>From: </b>"+json.from); $('#to').html("<b>To: </b>"+json.to); $('#tableCustomer').html("<b>Customer: </b>"+json.customer); $('#tableExecutive').html("<b>Executive: </b>"+json.executive); $('#category_text').html("<b>Category: </b>"+json.category); $('#size_text').html("<b>Size: </b>"+json.size); $('#colour_text').html("<b>Colour: </b>"+json.colour);$('#amount').html("<b>Total: </b> Rs. "+json.amount); return json.data; } 
                }
                , columns: [ { data: "id" }, { data: "category" }, { data: "size" }, { data: "colour" }, { data: "submitted_on" }, { data: "user" }, { data: "price" } ]
                // , columnDefs : [{ "render": function ( data, type, row ) { return number_format(data, 2, '.', ',')  ; }, "targets": 5, className: 'text-right' }, { "render": function ( data, type, row ) { return number_format(data, 2, '.', ',')  ; }, "targets": 6, className: 'text-right' }, { "targets": 4, className: 'text-right' } ]
        });

        //table.buttons().container().appendTo('.outstanding_wrapper' );

        $( "button" ).click(function(event) {
            event.preventDefault();

            var startDate = $('#start').val();
            var endDate = $('#end').val();
            // var executive = $('#executive').val();
            // var customer = $('#customerName').val();
            // var salesMonth = $('#salesMonth').val();

            if(startDate==""){
                $('#start').val("");
                $('#end').val("");
            }

            table.ajax.reload();

            // var serializedData = "startDate=" + startDate + "&endDate=" + endDate + "&executive=" + executive + "&customer=" + customer + "&salesMonth="+ salesMonth;

            // $.alert({
            //     type: 'red',
            //     title: 'Alert!',
            //     content: "No records found for the selected month",
            // });

        });

        $('#start').datetimepicker({
            minView: 2,
            format: 'yyyy-mm-dd',
            startDate: '2017-03-01',
            endDate: new Date(),
            weekStart: 1,
            todayBtn:  1,
            todayHighlight: 1,
            showMeridian: 1,
            startView: 2,
            forceParse: 0,                    
            autoclose: true
        });

        $('#end').datetimepicker({
            minView: 2,
            format: 'yyyy-mm-dd',
            endDate: new Date(),
            weekStart: 1,
            todayBtn:  1,
            todayHighlight: 1,
            showMeridian: 1,
            startView: 2,
            forceParse: 0,                    
            autoclose: true
        });

        $('#start').datetimepicker().on('changeDate', function(ev){
            $('#end').datetimepicker('setStartDate', $('#start').val());                
            $('#end').datetimepicker('show');
            $("#salesMonth").val("0");
        });

        $('#end').on('click', function(ev){
            if($('#start').val()==""){
                $('#end').datetimepicker('hide');
                $('#start').datetimepicker('show');
            }
        });

        $('#end').datetimepicker().on('changeDate', function(ev){
            $("#salesMonth").val("0");
        });

        $('#salesMonth').on('change', function (e) {
            $('#start').val("");
            $('#end').val("");
        });

    }); 

    function historyMonth(receivedMonth){
        if(receivedMonth=="LDecember"){
            var month = "December";
            var year = new Date().getFullYear()-1;            
        }
        else if(receivedMonth=="LNovember"){
            var month = "November";
            var year = new Date().getFullYear()-1; 
        }
        else{
            var month = receivedMonth;
            var year = new Date().getFullYear();
        }

        return month +" "+year;
    }

    function number_format (number, decimals, dec_point, thousands_sep) {
        // Strip all characters but numerical ones.
        number = (number + '').replace(/[^0-9+\-Ee.]/g, '');
        var n = !isFinite(+number) ? 0 : +number,
            prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
            sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
            dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
            s = '',
            toFixedFix = function (n, prec) {
                var k = Math.pow(10, prec);
                return '' + Math.round(n * k) / k;
            };
        // Fix for IE parseFloat(0.55).toFixed(0) = 0;
        s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
        if (s[0].length > 3) {
            s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
        }
        if ((s[1] || '').length < prec) {
            s[1] = s[1] || '';
            s[1] += new Array(prec - s[1].length + 1).join('0');
        }
        return s.join(dec);
    }

</script>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nishe\resources\views/report/advertisement.blade.php ENDPATH**/ ?>