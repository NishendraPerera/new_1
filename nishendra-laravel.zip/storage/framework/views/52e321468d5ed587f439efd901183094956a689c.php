<?php $__env->startSection('content'); ?>

<!--================Home Banner Area =================-->

    <!--================Blog Area =================-->

    

    <div class="wrapper row3">
        <main class="hoc container clear" style="padding: 40px 0;"> 
          <!-- main body -->
          <!-- ################################################################################################ -->
          <div class="content three_quarter first"> 
            <ul class="nospace group">

            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <div class="one_quarter first" style="margin: 10px 0;">
                    <a href="<?php echo e(route('single', ['id' => $article->id])); ?>"><img src="<?php echo e($article->link); ?>" alt="" style="width:100%;" /></a>
                </div>
                <div class="three_quarter">
                  <article>
                    <figcaption class="heading"><a href="<?php echo e(route('single', ['id' => $article->id])); ?>"><?php echo e($article->title); ?></a></figcaption>
                  </figure>
                  <!-- <em>Job Type Here</em> -->
                  <p><?php echo e(substr(strip_tags(html_entity_decode($article->content)),0, 200)); ?>[<a href="<?php echo e(route('single', ['id' => $article->id])); ?>">&hellip;</a>] </p>

                </article>
                </div>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              
            </ul>

            

            <?php $paginator = $articles;  ?>

            <?php json_decode($articles, true); ?>

            <?php echo e($articles->previousPageUrl()); ?>


            <?php if($paginator->hasPages()): ?>
                <ul class="pagination">
                    
                    <?php if($paginator->onFirstPage()): ?>
                        <li class="disabled"><span>&laquo;</span></li>
                    <?php else: ?>
                        <li><a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">&laquo;</a></li>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if(is_string($element)): ?>
                            <li class="disabled"><span><?php echo e($element); ?></span></li>
                        <?php endif; ?>

                        
                        <?php if(is_array($element)): ?>
                            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $paginator->currentPage()): ?>
                                    <li class="active"><span><?php echo e($page); ?></span></li>
                                <?php else: ?>
                                    <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($paginator->hasMorePages()): ?>
                        <li><a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">&raquo;</a></li>
                    <?php else: ?>
                        <li class="disabled"><span>&raquo;</span></li>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>
      
            <nav class="pagination">
                
              <ul>
                
                
                
              </ul>
            </nav>
      
          </div>

          <div class="sidebar one_quarter">
            <h6>Recent Videos</h6>
      
            <a href="javascript:void(0);"> <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed. </p> </a>
      
            <a href="javascript:void(0);"> <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed.</p> </a>
      
            <a href="javascript:void(0);"> <p>Nuncsed sed conseque a at quismodo tris mauristibus sed habiturpiscinia sed.</p> </a>
          </div>
      
        </main>
      </div>
    
    <section class="blog_area padding_top">
        <div class="container">
            <div class="row">
                <h2>Articles</h2>
            </div>

            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="whole-wrap">
                    <div class="container box_1170">
                        <div class="section-top-border">
                            <div class="row links">
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('single', ['id' => $article->id])); ?>"><img src="<?php echo e($article->link); ?>" alt="" class="img-fluid"></a>
                                </div>
                                <div class="col-md-9 mt-sm-20">
                                <h3 class="mb-30"><a href="<?php echo e(route('single', ['id' => $article->id])); ?>"><?php echo e($article->title); ?></a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <nav>
                <ul class="pagination justify-content-center pagination-lg">
                    <?php echo e($articles->links()); ?>

                </ul>
            </nav>
            
        </div>
    </section>
                

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nishe\resources\views/frontend/articles.blade.php ENDPATH**/ ?>