<?php $__env->startSection('content'); ?>

<div id="image-slider" class="splide">
	<div class="splide__track">
		<ul class="splide__list">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="splide__slide">
                    <img src="<?php echo e($slider->link); ?>">
                    <div class="slider_text">
                    <h1 class="slider_heading"><?php echo e($slider->title); ?></h1>
                    <div class="slider_desctiption">
                        <?php echo e($slider->description); ?>

                    </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
    </div>
</div>

<div class="wrapper row3">
    <main class="hoc container clear"> 
      <article class="group">
        <div class="one_half first">
          <h6 class="heading underline font-x2">Pope Francis says...</h6>
          <p> “Work is precisely from the human being. It expresses his dignity of being created in the image of God. Therefore it is said that work is sacred,” </p>
            
          <p> Because of this, he added, managing employment “is a great human and social responsibility which can't be left in the hands of the few, or discharged to a divinized market.” </p>
            
            <p>The Pope spoke to pilgrims present in the Vatican's Paul VI Hall for his Wednesday general audience. His comments are part of his continued series of catechesis on the family&hellip;</p>
        </div>
        <div class="one_half"><a class="imgover" href="javascript:void(0);"><img class="borderedbox inspace-10" src="<?php echo e(asset('template/images/pope.jpeg')); ?>" alt=""></a></div>
      </article>
      <div class="clear"></div>
    </main>
</div>

<div class="wrapper bgded overlay dark" style="background-image:url('<?php echo e(asset('template/images/vision.jpg')); ?>');">
    <div id="shout" class="hoc container clear"> 
        <article>
        <h3 class="heading font-x2">Vision</h3>
        <p>To Provide an efficient and viable service to the Multi-religious and multi-ethnic Population in Sri Lanka, to build a Community in the Spirit of Christ through the print and publication media. </p>
        </article>
        <br>
        <article>
        <h3 class="heading font-x2">Mission</h3>
        <p>By updating and improving the equipments and Machinery to provide proper facilities to work and For training Prepress and Printing technicians and Other personnel to assist the Sri Lankan community To experience the Spirit of Christ in the Printing And Publishing media.</p>
        </article>
    </div>
</div>

<div class="wrapper row2">
    <section class="hoc container clear"> 
      <div class="center btmspace-80">
        <h6 class="heading underline font-x2">Recent Articles</h6>
      </div>
      <ul class="nospace group latest">

        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="one_third <?php if($key==0): ?> first <?php endif; ?>">
                <article>
                <time><i class="far fa-calendar-alt rgtspace-5"></i> <?php echo e($article->date); ?> </time>
                <div class="excerpt">

                    <a href="<?php echo e(route('single', ['id' => $article->id] )); ?>">

                    <img src="<?php echo e($article->link); ?>" alt="">

                    
                    
                    <br> <br>

                    <h6 class="heading"><?php echo e($article->title); ?></h6>

                    </a>

                    
                    <ul class="meta">
                    <li><i class="fas fa-user rgtspace-5"></i> <a href="javascript:void(0)"><?php echo e($article->user); ?></a></li>
                    </ul>
                </div>
                </article>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>
      <footer class="view_more"><a class="btn" href="javascript:void(0);">View More</a></footer>

    </section>
</div>

<div class="wrapper bgded overlay light" style="background-image:url('<?php echo e(asset('template/images/bookshop.jpg')); ?>');">
    <section id="cta" class="hoc container clear"> 
      <h6 class="three_quarter first">Colombo Catholic Press Bookshop</h6>
      <footer class="one_quarter"><a class="btn" href="http://www.colomboarchdiocesancatholicpress.com/book-shop.php">Click here to visit</a></footer>
    </section>
</div>

<div class="wrapper row3">
    <section id="team" class="hoc container clear"> 
      <div class="center btmspace-80">
        <h6 class="heading underline font-x2">Recent Videos</h6>
      </div>
      <ul class="nospace group">

        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li class="one_half <?php if($key==0): ?> first <?php endif; ?>">
            <video
            id="my-video"
            class="video-js vjs-big-play-centered vjs-16-9"
            controls
            preload="none"
            style="width: 100%"
            poster="<?php echo e($video->thumbnail_link); ?> "
            data-setup="{}"
            >
            <source src="<?php echo e($video->link); ?>" type="video/mp4" />
            </video>
            <article>
            <figcaption class="heading"><a href="<?php echo e(route('single_video', ['id' => $video->id] )); ?>">  <?php echo e($video->title); ?> </a></figcaption>
            </figure>
            

            </article>
        </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </ul>

    <footer class="view_more"><a class="btn" href="javascript:void(0);">View More</a></footer>
      
    </section>
</div>

    <!-- product_list part end-->

    <!-- subscribe_area part start-->
    
    <!--::subscribe_area part end::-->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nishe\resources\views/frontend/index.blade.php ENDPATH**/ ?>