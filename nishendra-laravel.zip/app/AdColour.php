<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdColour extends Model
{
    //
}
