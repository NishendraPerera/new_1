<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdPrice extends Model
{
    //
}
